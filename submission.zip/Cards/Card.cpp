#include "../utilities.h"
#include "Card.h"
#include <string>

Card::Card(std::string name):m_name(name){
    int count = 0;
    for(char c : name){
        if(count>15){
            throw InvalidName();
        }
        if(!isalpha(c)){
            throw InvalidName();
        }
        count++;
    }
}

void Card::print(std::ostream& out) const{}

std::ostream& operator << (std::ostream& out, const Card& card){
     printCardDetails(out, card.m_name); 
    card.print(out);
    printEndOfCardDetails(out);
    return out;

}


Card::BattleCard::BattleCard(std::string name): Card(name){}

void Card::BattleCard::applyEncounter(Player& player) const{
    if(player.getAttackStrength() >= this->getForce()){
        player.levelUp();
        player.addCoins(this->getCoins());
        printWinBattle(player.getName(), this->m_name);
    }
    else{
        player.damage(this->getDamage());
        printLossBattle(player.getName(), this->m_name);
        const Witch* witchPtr = dynamic_cast<const Witch*>(this);
        if(!(witchPtr == nullptr)){
            player.changeForce(-1);
        } 

    }
}

 void Card::BattleCard::print(std::ostream& out) const{
    const Dragon* dragonPtr = dynamic_cast<const Dragon*>(this);
    bool isDragon = !(dragonPtr == nullptr);
    printMonsterDetails(out, this->getForce(), this->getDamage(), this->getCoins(), isDragon);
 }
